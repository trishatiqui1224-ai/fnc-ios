E:/Project/Fight\ Night\ Champion/test_codegen/generated/codegen.build.stamp: \
  E:/Project/Fight\ Night\ Champion/test_codegen/fnc_manifest.toml \
  E:/Project/Fight\ Night\ Champion/Fight\ Night\ Champion\ (Europe)/default.xex
